
var HttpClient = require('./HttpClient');

var CatalogClient = module.exports = function () {

    var ALBUMS_URI = 'http://localhost:3000/albums';
    var ALBUM_URI  = 'http://localhost:3000/albums/{_}';
    var http = new HttpClient();

    this.addAlbum = function (album, callback) {
        var url  = ALBUM_URI.replace('{_}', album.id);
        var data = JSON.stringify(album);
        http.PUT(url, data, callback)
    }; // method

    this.getAlbum = function (albumID, callback) {
        var url = ALBUM_URI.replace('{_}', albumID);
        http.GET(url, function (resp) {
            var album = JSON.parse(resp.body);
            callback(album);
        });
    }; // method

    this.removeAlbum = function (albumID, callback) {
        var url = ALBUM_URI.replace('{_}', albumID);
        http.DELETE(url, callback);
    }; // method

    this.getAlbums = function (callback) {
        http.GET(ALBUMS_URI, function (resp) {
            var albums = JSON.parse(resp.body);
            callback(albums);
        });
    }; // method

}; // class